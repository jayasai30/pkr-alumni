# PKR Alumni (installable app + website)

Your old PHP/MySQL Alumni site, rebuilt as a **free, installable web app** that works on every phone and every laptop.

* **Phones:** open the link, tap *Install app* (Android) or *Share > Add to Home Screen* (iPhone). It gets an icon and opens full-screen like a normal app.
* **Laptops:** just open the link in any browser. Nothing to install. (Chrome and Edge can also install it.)
* **Free:** no paid server, no database fee, no app-store fee.

All your features are kept: home, about (with the college video), gallery, contact, ratings (admin approves), alumni sign-up with photo, admin approval, login, profile editing, alumni directory with search, private chat, group chat, admin panel.

## Put it online for free (about 20 minutes, once)

You need three free accounts: **GitHub** (stores the code), **Turso** (permanent database), **Render** (runs the app).
The database must be Turso, because Render's free disk is erased whenever the app restarts.

1. **GitHub.** Create a new repository, then *Add file > Upload files* and upload everything in this folder (keep the `public` folder).
2. **Turso** (turso.tech, sign up, no card needed). Create a database, then copy its URL (starts with `libsql://`) and create a **database token**.
3. **Render** (render.com). *New > Blueprint*, choose your GitHub repository. When asked, fill in:
   * `ADMIN_PASSWORD`: choose a strong password. This is your admin login.
   * `TURSO_URL` and `TURSO_TOKEN`: from step 2.
4. Wait for the build. Render gives you a link like `https://pkr-alumni.onrender.com`. **That link is your website and your app.** Share it with everyone.
5. Open `your-link/#/admin`, log in with username `admin` and your `ADMIN_PASSWORD`, and approve registrations.

Good to know about the free plans: Render puts a free app to sleep after 15 minutes without visitors and it takes about a minute to wake up on the next visit. Turso's free plan allows 5 GB and generous monthly reads and writes, far above what an alumni site needs.

## Run it on your own computer (testing)

Needs Node.js 22.5 or newer.

```
node server.js
```

Open http://localhost:3000. The first start prints the admin password if you did not set `ADMIN_PASSWORD`. Data is saved in `data/alumni.db`.

## Install the app on a phone

The phone needs the **https** link (Render provides it). Open the link on the phone:
* Android (Chrome): menu (three dots) > *Install app*.
* iPhone (Safari only): Share button > *Add to Home Screen*.

The app also has an *Install the app* page with these steps (footer link).

## Security notes

* Passwords are stored hashed (scrypt). Sessions use signed HttpOnly cookies. All forms are validated on the server.
* The alumni directory, profiles, photos and chats are visible only to approved, logged-in alumnae.
* Admin login is rate-limited. Change the admin password under Admin > Account after first login.
* A forgotten alumna password: Admin > Alumni > *Reset password* gives a temporary one.
* **Rotate the secrets from your old project.** `password.txt` and four PHP files contained a Gmail app password and Brevo SMTP keys. Treat them as exposed: delete or regenerate them in Google and Brevo. They are not used or copied into this app.

## Optional emails

Set `BREVO_API_KEY`, `MAIL_FROM` (a sender you verified in Brevo) and `CONTACT_NOTIFY_TO`. The app then emails an alumna when she is approved and alerts the college about new registrations and contact messages. Without these the app works fine; the admin panel shows everything.

## Files

* `server.js` API and web server, `db.js` database (SQLite locally, Turso online), `public/` the app (pages, styles, service worker, icons).
* `test/mock-turso.js` a local stand-in for Turso, only for developers.
