// Service worker: caches the app shell so the app opens instantly and works offline-ish.
// Never caches /api (private data). Bump VERSION when shipping new front-end files.
const VERSION = 'pkr-v1';
const SHELL = ['/', '/index.html', '/app.js', '/style.css', '/manifest.webmanifest',
  '/img/emblem.jpg', '/img/campus1.jpg', '/img/campus2.jpg', '/icons/icon-192.png', '/icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/') || url.pathname === '/healthz') return;
  if (req.headers.has('range')) return; // let the browser stream video directly
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).catch(() => caches.match('/index.html')));
    return;
  }
  // stale-while-revalidate for static files
  e.respondWith(caches.open(VERSION).then(async (c) => {
    const hit = await c.match(req);
    const net = fetch(req).then((r) => { if (r.ok && !/\.mp4$/.test(url.pathname)) c.put(req, r.clone()); return r; }).catch(() => hit);
    return hit || net;
  }));
});
