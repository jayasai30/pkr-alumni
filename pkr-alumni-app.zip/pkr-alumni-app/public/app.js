(() => {
'use strict';
// Make replaceChildren accept nested arrays and skip null/false (native version would print "null").
const nativeReplace = Element.prototype.replaceChildren;
Element.prototype.replaceChildren = function (...kids) {
  return nativeReplace.apply(this, kids.flat(Infinity).filter((k) => k !== null && k !== undefined && k !== false));
};
const main = document.getElementById('main');
const state = { user: null, unread: 0, admin: false };
let cleanups = [];
let installEvt = null;
let nextRoute = null;

/* ---------- tiny DOM + API helpers ---------- */
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value' || k === 'checked' || k === 'disabled') el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  const add = (c) => {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) return c.forEach(add);
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  };
  kids.forEach(add);
  return el;
}
const ICONS = {
  home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
  info: 'M12 8h.01M11 12h1v5h1M12 21a9 9 0 100-18 9 9 0 000 18z',
  image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M9 9h.01',
  star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z',
  login: 'M15 4h4v16h-4M10 8l4 4-4 4M14 12H3',
  people: 'M9 11a4 4 0 100-8 4 4 0 000 8zM2 21v-1a6 6 0 0112 0v1M17 11a3 3 0 100-6M22 21v-1a5 5 0 00-4-4.9',
  chat: 'M21 12a8 8 0 01-11.5 7.2L3 21l1.8-6.2A8 8 0 1121 12z',
  group: 'M4 5h16v11H9l-5 4zM8 9h8M8 12h5',
  me: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  search: 'M11 18a7 7 0 100-14 7 7 0 000 14zM21 21l-5-5',
  mentor: 'M12 3l9 5-9 5-9-5zM7 11v5c0 1.5 2.2 3 5 3s5-1.5 5-3v-5',
};
function icon(name) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', ICONS[name]); s.append(p);
  return s;
}
async function api(method, path, body) {
  let r;
  try {
    r = await fetch(path, {
      method, credentials: 'same-origin',
      headers: { 'X-Requested-With': 'pkr', ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch { throw new Error('Cannot reach the server. Check your internet connection and try again.'); }
  let data = null;
  try { data = await r.json(); } catch { /* not json */ }
  if (!r.ok) { const e = new Error((data && data.error) || 'Something went wrong. Please try again.'); e.status = r.status; throw e; }
  return data;
}
function toast(text) {
  const t = h('div', { class: 'toast', role: 'status' }, text);
  document.body.append(t);
  setTimeout(() => t.remove(), 3200);
}
const COLORS = ['#3d4a9a', '#7a3b8f', '#1f7a7a', '#a24a2d', '#2d6a3e', '#8a2f53', '#355c8c'];
function avatar(name, src, cls = '') {
  if (src) return h('img', { class: 'avatar ' + cls, src, alt: '', loading: 'lazy' });
  const n = name || '?';
  let hash = 0; for (const c of n) hash = (hash * 31 + c.charCodeAt(0)) >>> 0;
  return h('div', { class: 'avatar ' + cls, style: `background:${COLORS[hash % COLORS.length]}`, 'aria-hidden': 'true' }, n.trim()[0].toUpperCase());
}
function fmtTime(iso) {
  const d = new Date(iso), n = new Date();
  const t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  return d.toDateString() === n.toDateString() ? t : d.toLocaleDateString([], { day: 'numeric', month: 'short' }) + ', ' + t;
}
const fmtDate = (iso) => new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
function stars(n, interactive, onPick) {
  if (!interactive) return h('span', { class: 'stars', role: 'img', 'aria-label': `${n} out of 5 stars` }, [1, 2, 3, 4, 5].map((i) => h('span', { class: i <= Math.round(n) ? 'on' : '' }, '★')));
  const wrap = h('div', { class: 'stars', role: 'radiogroup', 'aria-label': 'Rating' });
  const paint = (v) => [...wrap.children].forEach((b, i) => { b.classList.toggle('on', i < v); b.setAttribute('aria-checked', i + 1 === v); });
  [1, 2, 3, 4, 5].forEach((i) => wrap.append(h('button', { type: 'button', role: 'radio', 'aria-label': `${i} star${i > 1 ? 's' : ''}`, onclick: () => { onPick(i); paint(i); } }, '★')));
  return wrap;
}
async function resizePhoto(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error('That file could not be read as an image.')); i.src = url; });
    const S = 480, c = document.createElement('canvas'); c.width = c.height = S;
    const side = Math.min(img.width, img.height);
    c.getContext('2d').drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
    return c.toDataURL('image/jpeg', 0.82);
  } finally { URL.revokeObjectURL(url); }
}
const onLeave = (fn) => cleanups.push(fn);
function every(ms, fn) { const id = setInterval(() => { if (!document.hidden) fn(); }, ms); onLeave(() => clearInterval(id)); }
const showErr = (box, e) => { box.className = 'msg err'; box.textContent = e.message; box.hidden = false; box.scrollIntoView({ block: 'nearest' }); };

/* ---------- session ---------- */
async function loadMe() {
  try {
    const r = await api('GET', '/api/me');
    state.user = r.user; state.unread = r.unread; state.admin = r.admin;
  } catch { /* offline: keep what we have */ }
  renderNav();
}

/* ---------- navigation ---------- */
function renderNav() {
  const here = '/' + (location.hash.slice(2).split('/')[0] || '');
  const link = (to, text, cls = '') => h('a', { href: '#' + to, class: cls, 'aria-current': here === to ? 'page' : null }, text);
  const nav = document.getElementById('nav'); nav.replaceChildren();
  nav.append(link('/', 'Home', 'hide-sm'), link('/about', 'About', 'hide-sm'), link('/gallery', 'Gallery', 'hide-sm'),
    link('/reviews', 'Reviews', 'hide-sm'), link('/contact', 'Contact', 'hide-sm'));
  if (state.user) {
    nav.append(link('/alumni', 'Alumni', 'hide-sm'),
      h('a', { href: '#/chat', class: 'hide-sm', 'aria-current': here === '/chat' ? 'page' : null }, 'Chats', state.unread ? h('span', { class: 'badge' }, state.unread) : null),
      link('/group', 'Group chat', 'hide-sm'), link('/me', 'My profile', 'hide-sm'));
  } else nav.append(link('/signup', 'Sign up', 'hide-sm'), link('/login', 'Log in'));
  if (installEvt) nav.append(h('button', { class: 'install', onclick: doInstall }, 'Install app'));

  const tabs = document.getElementById('tabs'); tabs.replaceChildren();
  const tab = (to, ic, text, badge) => h('a', { href: '#' + to, 'aria-current': here === to ? 'page' : null }, icon(ic), text, badge ? h('span', { class: 'badge' }, badge) : null);
  if (state.user) tabs.append(tab('/', 'home', 'Home'), tab('/alumni', 'people', 'Alumni'), tab('/chat', 'chat', 'Chats', state.unread), tab('/group', 'group', 'Group'), tab('/me', 'me', 'Me'));
  else tabs.append(tab('/', 'home', 'Home'), tab('/about', 'info', 'About'), tab('/gallery', 'image', 'Gallery'), tab('/reviews', 'star', 'Reviews'), tab('/login', 'login', 'Log in'));
}
async function doInstall() {
  if (!installEvt) return;
  installEvt.prompt();
  await installEvt.userChoice.catch(() => {});
  installEvt = null; renderNav();
}
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); installEvt = e; renderNav(); });
window.addEventListener('appinstalled', () => { installEvt = null; renderNav(); toast('PKR Alumni is installed.'); });
window.addEventListener('online', () => { document.getElementById('offline').hidden = true; });
window.addEventListener('offline', () => { document.getElementById('offline').hidden = false; });
if (!navigator.onLine) document.getElementById('offline').hidden = false;

function footer() {
  return h('footer', { class: 'site' }, h('div', { class: 'wrap' },
    h('div', { class: 'row' },
      h('a', { href: '#/contact' }, 'Contact the college'), h('a', { href: '#/install' }, 'Install the app'), h('a', { href: '#/admin' }, 'Admin'),
      h('a', { href: 'https://www.instagram.com/pkr_arts_college/?hl=en', target: '_blank', rel: 'noopener noreferrer' }, 'Instagram'),
      h('a', { href: 'http://www.youtube.com/@p.k.r.artscollegeforwomeng9065', target: '_blank', rel: 'noopener noreferrer' }, 'YouTube'),
      h('a', { href: 'https://in.linkedin.com/company/pkr-arts-college-for-women', target: '_blank', rel: 'noopener noreferrer' }, 'LinkedIn'),
      h('a', { href: 'https://www.pkrarts.org', target: '_blank', rel: 'noopener noreferrer' }, 'College website')),
    h('p', { style: 'margin:12px 0 0' }, '© PKR Arts College for Women, Gobichettipalayam. All rights reserved.')));
}

/* ---------- pages: public ---------- */
const flame = () => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 34 46'); s.setAttribute('class', 'flame'); s.setAttribute('aria-hidden', 'true');
  s.innerHTML = '<g class="f"><path d="M17 2c2 7 10 11 10 22a10 10 0 01-20 0C7 18 11 15 12 9c2 2 3 4 3 6 2-3 3-8 2-13z" fill="#e8a317"/><path d="M17 18c1 4 5 6 5 11a5 5 0 01-10 0c0-3 2-4 3-6l1 2c1-2 1-4 1-7z" fill="#fff3c4"/></g>';
  return s;
};
async function home() {
  const stats = h('small', {}, '');
  main.replaceChildren(
    h('section', { class: 'hero' }, h('div', { class: 'wrap' },
      flame(),
      h('h1', {}, 'Stay close to the college that taught you.'),
      h('p', {}, 'PKR Alumni connects the women of PKR Arts College, Gobichettipalayam. Find classmates, ask a senior for career advice, and hear what the college is doing next.'),
      h('div', { class: 'row' },
        state.user ? [h('a', { class: 'btn lamp', href: '#/alumni' }, 'Find alumni'), h('a', { class: 'btn ghost', href: '#/group' }, 'Open group chat')]
          : [h('a', { class: 'btn lamp', href: '#/signup' }, 'Join the network'), h('a', { class: 'btn ghost', href: '#/login' }, 'Log in')]),
      stats)),
    h('section', { class: 'section' }, h('div', { class: 'wrap' },
      h('h2', {}, 'What you can do here'),
      h('ul', { class: 'ways' },
        h('li', {}, icon('search'), h('div', {}, h('h3', {}, 'Find classmates and seniors'), h('p', {}, 'Search by name, degree, graduation year, company or city.'))),
        h('li', {}, icon('chat'), h('div', {}, h('h3', {}, 'Message anyone privately'), h('p', {}, 'Ask about a job, a course or a city you are moving to.'))),
        h('li', {}, icon('group'), h('div', {}, h('h3', {}, 'Talk in the alumni group'), h('p', {}, 'Share openings, reunions and news with everyone at once.'))),
        h('li', {}, icon('mentor'), h('div', {}, h('h3', {}, 'Mentor the next batch'), h('p', {}, 'Tell current students what your first job was really like.'))))),
    ),
    footer());
  try {
    const s = await api('GET', '/api/stats');
    stats.textContent = s.alumni
      ? `${s.alumni} alumnae ${s.alumni === 1 ? 'has' : 'have'} joined so far.` + (s.rating ? ` Reviewers rate the college ${s.rating} out of 5.` : '')
      : 'Be the first to join. Registration takes two minutes.';
  } catch { stats.remove(); }
}

function about() {
  main.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-title' }, h('h1', {}, 'About PKR Arts College Alumni Platform')),
    h('video', { class: 'video', controls: true, playsinline: true, preload: 'none', poster: '/img/about-poster.jpg' }, h('source', { src: '/img/about.mp4', type: 'video/mp4' }), 'Your browser does not support video.'),
    h('div', { class: 'prose' },
      h('h2', { id: 'objective' }, 'Objective of the alumni website'),
      h('p', {}, 'The Alumni Platform of PKR Arts College for Women aims to create a dynamic space for interaction, engagement, and growth. The main objective is to bridge the gap between alumni and current students, fostering a collaborative environment. Through this platform, alumni can contribute by offering career advice, mentorship, and by participating in the college’s future initiatives.'),
      h('p', {}, 'The website also serves as a networking hub, giving alumni the opportunity to stay connected with each other and the college. It acts as a repository for alumni success stories and achievements, inspiring current students to excel in their own paths.'),
      h('h2', { id: 'mission' }, 'Our mission'),
      h('p', {}, 'Our mission is to build a strong and lasting relationship between the college and its alumni network. The platform facilitates collaboration, support, and knowledge exchange among alumni, students, and faculty. It is a place where alumni can actively engage with their alma mater, share their expertise, and help current students navigate their academic and professional journeys.'),
      h('p', {}, 'We envision a global network of alumni who can collectively offer guidance, resources, and opportunities to students, ensuring that the institution remains a center of excellence in education and professional development.'),
      h('h2', { id: 'aim' }, 'Our aim'),
      h('p', {}, 'The primary aim is to foster a thriving community of alumni and students: easy communication, mentorship, and a space to share job opportunities and professional advice. The platform also helps the college stay connected with its alumni, track their career progress, and draw on their expertise for future generations.'),
      h('ul', {},
        h('li', {}, 'Create a space where alumni share knowledge, resources and experiences with students.'),
        h('li', {}, 'Encourage alumni to take part in college activities, give career guidance and mentor current students.'),
        h('li', {}, 'Connect students with alumni in relevant fields for jobs and internships.'),
        h('li', {}, 'Build a sense of pride and belonging among alumni, even after graduation.'),
        h('li', {}, 'Celebrate the accomplishments of the alumni community to inspire future students and faculty.'))),
    h('p', {}, h('a', { class: 'btn', href: '#/contact' }, 'Contact the college'))), footer());
}

function gallery() {
  const items = [['/img/campus1.jpg', 'The college building seen from the playground'], ['/img/campus2.jpg', 'The central avenue between the two main blocks'], ['/img/emblem.jpg', 'College emblem: Education, Enlightenment, Discipline, Service']];
  const dlg = h('dialog', { 'aria-label': 'Photo viewer', onclick: () => dlg.close() }, h('img', { alt: '' }));
  main.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-title' }, h('h1', {}, 'Gallery'), h('p', { class: 'lead' }, 'Tap a photo to see it larger. More photos are on the college Instagram page.')),
    h('div', { class: 'gallery' }, items.map(([src, alt]) => h('button', { type: 'button', 'aria-label': 'Open photo: ' + alt, onclick: () => { dlg.firstChild.src = src; dlg.firstChild.alt = alt; dlg.showModal(); } }, h('img', { src, alt, loading: 'lazy' })))),
    dlg,
    h('p', { style: 'margin-top:22px' }, h('a', { class: 'btn ghost', href: 'https://www.instagram.com/pkr_arts_college/?hl=en', target: '_blank', rel: 'noopener noreferrer' }, 'More on Instagram'))), footer());
}

function contact() {
  const msg = h('div', { hidden: true });
  const form = h('form', { class: 'form', onsubmit: async (e) => {
    e.preventDefault(); const btn = form.querySelector('button'); btn.disabled = true; msg.hidden = true;
    try { const r = await api('POST', '/api/contact', Object.fromEntries(new FormData(form))); form.reset(); msg.className = 'msg ok'; msg.textContent = r.message; msg.hidden = false; }
    catch (err) { showErr(msg, err); } finally { btn.disabled = false; }
  } },
    h('label', { for: 'c-name' }, 'Your name'), h('input', { id: 'c-name', name: 'name', required: true, maxlength: 80, autocomplete: 'name' }),
    h('label', { for: 'c-email' }, 'Your email'), h('input', { id: 'c-email', name: 'email', type: 'email', required: true, autocomplete: 'email' }),
    h('label', { for: 'c-msg' }, 'Message'), h('textarea', { id: 'c-msg', name: 'message', required: true, maxlength: 2000 }),
    msg, h('button', { class: 'btn', type: 'submit' }, 'Send message'));
  main.replaceChildren(h('div', { class: 'wrap contact' },
    h('div', { class: 'page-title' }, h('h1', {}, 'Contact us')),
    h('div', { class: 'narrow', style: 'margin:0' },
      h('h3', {}, 'PKR Arts College for Women'),
      h('p', {}, 'Gobichettipalayam, Tamil Nadu, India'),
      h('dl', {},
        h('dt', {}, 'Email'), h('dd', {}, h('a', { href: 'mailto:pkroffice@gmail.com' }, 'pkroffice@gmail.com')),
        h('dt', {}, 'Phone'), h('dd', {}, h('a', { href: 'tel:+919842729393' }, '098427 29393')),
        h('dt', {}, 'Other phones'), h('dd', {}, h('a', { href: 'tel:+914285222335' }, '04285 222 335'), ', ', h('a', { href: 'tel:+914285222258' }, '04285 222 258')))),
    form), footer());
}

async function reviews() {
  let picked = 0;
  const msg = h('div', { hidden: true });
  const list = h('div', {}, h('p', { class: 'meta' }, 'Loading reviews…'));
  const form = h('form', { class: 'form', onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    const btn = form.querySelector('button[type=submit]'); btn.disabled = true;
    try {
      const r = await api('POST', '/api/ratings', { ...Object.fromEntries(new FormData(form)), rating: picked });
      form.reset(); picked = 0; form.querySelectorAll('.stars button').forEach((b) => b.classList.remove('on'));
      msg.className = 'msg ok'; msg.textContent = r.message; msg.hidden = false;
    } catch (err) { showErr(msg, err); } finally { btn.disabled = false; }
  } },
    h('label', {}, 'Your rating'), stars(0, true, (n) => { picked = n; }),
    h('label', { for: 'r-name' }, 'Your name'), h('input', { id: 'r-name', name: 'name', required: true, maxlength: 60, autocomplete: 'name' }),
    h('label', { for: 'r-email' }, 'Email (optional, never shown)'), h('input', { id: 'r-email', name: 'email', type: 'email', autocomplete: 'email' }),
    h('label', { for: 'r-review' }, 'Your review'), h('textarea', { id: 'r-review', name: 'review', maxlength: 600 }),
    msg, h('button', { class: 'btn', type: 'submit' }, 'Submit review'));
  main.replaceChildren(h('div', { class: 'wrap' }, h('div', { class: 'page-title' }, h('h1', {}, 'Rate PKR Arts College'), h('p', { class: 'lead' }, 'Reviews appear after the admin approves them.')),
    h('div', { class: 'narrow', style: 'margin:0' }, form), h('h2', { style: 'margin-top:36px' }, 'Recent reviews'), list), footer());
  try {
    const r = await api('GET', '/api/ratings');
    list.replaceChildren(
      r.count ? h('p', { class: 'meta' }, `Average ${r.average} out of 5 from ${r.count} review${r.count > 1 ? 's' : ''}`) : h('p', { class: 'empty' }, 'No reviews yet. Be the first to write one.'),
      r.reviews.map((v) => h('div', { class: 'review' }, h('div', { class: 'row' }, stars(v.rating), h('b', {}, v.name), h('span', { class: 'meta' }, fmtDate(v.created_at))), v.review ? h('p', {}, v.review) : null)));
  } catch (e) { list.textContent = e.message; }
}

function install() {
  const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  main.replaceChildren(h('div', { class: 'wrap prose' },
    h('div', { class: 'page-title' }, h('h1', {}, 'Install PKR Alumni'), h('p', { class: 'lead' }, 'The app is free and takes no space worth mentioning. It opens like any other app, without the browser bar.')),
    standalone ? h('p', { class: 'msg ok' }, 'You are already using the installed app.') : null,
    installEvt ? h('p', {}, h('button', { class: 'btn lamp', onclick: doInstall }, 'Install now')) : null,
    h('h2', {}, 'Android phone (Chrome, Edge, Samsung Internet)'),
    h('ol', { class: 'steps' }, h('li', {}, 'Open this website in Chrome.'), h('li', {}, 'Tap the menu (three dots) at the top right.'), h('li', {}, 'Tap Install app, or Add to Home screen.')),
    h('h2', {}, 'iPhone and iPad (Safari)'),
    h('ol', { class: 'steps' }, h('li', {}, 'Open this website in Safari. Other iPhone browsers cannot install apps.'), h('li', {}, 'Tap the Share button (square with an arrow).'), h('li', {}, 'Scroll down and tap Add to Home Screen, then Add.')),
    h('h2', {}, 'Laptop or desktop (Chrome, Edge)'),
    h('ol', { class: 'steps' }, h('li', {}, 'Open this website.'), h('li', {}, 'Click the install icon at the right end of the address bar, then Install.')),
    h('p', {}, 'You do not have to install anything. The website works in any browser on any laptop or phone.')), footer());
}

/* ---------- forms shared by sign up and edit profile ---------- */
const DEGREES = [['Arts', ['B.A. English Literature', 'B.A. Tamil Literature']],
  ['Science', ['B.Sc. Computer Science', 'B.Sc. Physics', 'B.Sc. Maths', 'B.Sc. Cyber Security', 'B.Sc. Information Technology', 'B.Sc. AI & ML']],
  ['Business', ['B.Com. Commerce', 'B.Com. CA', 'B.Com. Professional Accounting', 'B.Com. IT', 'B.B.A. Business Management']],
  ['Other', ['B.C.A.', 'M.C.A.', 'M.B.A.']]];
function field(label, name, o = {}) {
  const id = 'f-' + name;
  const input = o.type === 'textarea' ? h('textarea', { id, name, maxlength: o.max }) : h('input', { id, name, type: o.type || 'text', maxlength: o.max, required: o.required, autocomplete: o.auto, inputmode: o.mode, min: o.min, max: o.maxv, placeholder: o.ph });
  if (o.value !== undefined && o.value !== null) input.value = o.value;
  return h('div', { class: o.cls || '' }, h('label', { for: id }, label + (o.required ? ' *' : '')), input, o.hint ? h('p', { class: 'hint' }, o.hint) : null);
}
function profileForm(u, mode, onDone) {
  const v = (k) => (u && u[k] !== null && u[k] !== undefined ? u[k] : '');
  let photoData = null;
  const msg = h('div', { hidden: true });
  const preview = h('div', {}, avatar(v('full_name'), u && u.photo, 'lg'));
  const degree = h('select', { id: 'f-degree', name: 'degree', required: true }, h('option', { value: '' }, 'Select…'),
    DEGREES.map(([g, list]) => h('optgroup', { label: g }, list.map((d) => h('option', { value: d, selected: d === v('degree') }, d)))));
  const status = h('select', { id: 'f-status', name: 'status', required: true }, h('option', { value: '' }, 'Select…'),
    ['Employed', 'Unemployed', 'Higher Education', 'Other'].map((s) => h('option', { value: s, selected: s === v('status') }, s)));
  const emp = h('div', { class: 'grid2' }, field('Job role', 'job_role', { value: v('job_role'), max: 80, cls: 'x' }), field('Company name', 'company_name', { value: v('company_name'), max: 100 }), field('Company location', 'company_location', { value: v('company_location'), max: 100 }));
  const edu = h('div', { class: 'grid2' }, field('Institution name', 'institution_name', { value: v('institution_name'), max: 120 }), field('Course name', 'course_name', { value: v('course_name'), max: 100 }), field('Expected completion year', 'completion_year', { type: 'number', value: v('completion_year'), mode: 'numeric' }));
  const oth = h('div', {}, field('Please specify', 'other_specify', { value: v('other_specify'), max: 150 }));
  const sync = () => { emp.hidden = status.value !== 'Employed'; edu.hidden = status.value !== 'Higher Education'; oth.hidden = status.value !== 'Other'; };
  status.addEventListener('change', sync); sync();
  const photoIn = h('input', { id: 'f-photo', type: 'file', accept: 'image/*', required: mode === 'signup', onchange: async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try { photoData = await resizePhoto(f); preview.replaceChildren(h('img', { class: 'avatar lg', src: photoData, alt: 'Your photo preview' })); msg.hidden = true; }
    catch (err) { photoData = null; e.target.value = ''; showErr(msg, err); }
  } });
  const form = h('form', { class: 'form', onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    const btn = form.querySelector('button[type=submit]'); btn.disabled = true;
    const data = Object.fromEntries(new FormData(form));
    delete data.photo_file;
    if (photoData) data.photo = photoData;
    try { await onDone(data, msg); } catch (err) { showErr(msg, err); } finally { btn.disabled = false; }
  } },
    field('Full name', 'full_name', { required: true, value: v('full_name'), max: 80, auto: 'name' }),
    field('Location (city)', 'location', { required: true, value: v('location'), max: 100, auto: 'address-level2' }),
    h('label', { for: 'f-degree' }, 'Education *'), degree,
    field('Year of graduation', 'grad_year', { type: 'number', required: true, value: v('grad_year'), mode: 'numeric', ph: 'e.g. 2023' }),
    h('label', { for: 'f-status' }, 'Current status *'), status, emp, edu, oth,
    h('div', { class: 'grid2' }, field('Phone number', 'phone', { type: 'tel', required: true, value: v('phone'), max: 20, auto: 'tel' }), field('Email', 'email', { type: 'email', required: true, value: v('email'), max: 120, auto: 'email' })),
    mode === 'signup' ? field('Password', 'password', { type: 'password', required: true, max: 200, auto: 'new-password', hint: 'At least 8 characters.' }) : null,
    field('Goal or objective', 'objective', { type: 'textarea', value: v('objective'), max: 600, hint: 'Optional. Shown on your profile.' }),
    field('LinkedIn profile link', 'linkedin', { type: 'url', value: v('linkedin'), max: 300, ph: 'https://www.linkedin.com/in/…' }),
    h('label', { for: 'f-photo' }, mode === 'signup' ? 'Profile photo *' : 'Change profile photo'), h('div', { class: 'row' }, preview, photoIn),
    h('p', { class: 'hint' }, 'Your photo is resized on your device before it is uploaded.'),
    msg, h('button', { class: 'btn', type: 'submit' }, mode === 'signup' ? 'Submit registration' : 'Save changes'));
  form.querySelector('#f-degree').value = v('degree');
  return form;
}

function signup() {
  if (state.user) return (location.hash = '#/alumni');
  const wrap = h('div', { class: 'narrow' });
  const form = profileForm(null, 'signup', async (data) => {
    const r = await api('POST', '/api/register', data);
    wrap.replaceChildren(h('div', { class: 'page-title' }, h('h1', {}, 'Registration received')), h('p', { class: 'msg ok' }, r.message),
      h('p', {}, 'The college admin reviews every registration. Try logging in again in a day or two.'), h('a', { class: 'btn', href: '#/' }, 'Back to home'));
    scrollTo(0, 0);
  });
  wrap.append(h('div', { class: 'page-title' }, h('h1', {}, 'Join the alumni network'), h('p', { class: 'lead' }, 'Fill in your details. Your account is activated after the college admin approves it.')), form,
    h('p', {}, 'Already registered? ', h('a', { href: '#/login' }, 'Log in')));
  main.replaceChildren(wrap, footer());
}

function pwField(id, label, auto) {
  const input = h('input', { id, name: id, type: 'password', required: true, autocomplete: auto, maxlength: 200 });
  const show = h('button', { type: 'button', onclick: () => { input.type = input.type === 'password' ? 'text' : 'password'; show.textContent = input.type === 'password' ? 'Show' : 'Hide'; } }, 'Show');
  return h('div', {}, h('label', { for: id }, label), h('div', { class: 'pw' }, input, show));
}
function login() {
  if (state.user) return (location.hash = '#/alumni');
  const msg = h('div', { hidden: true });
  const form = h('form', { class: 'form', onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true; const btn = form.querySelector('button[type=submit]'); btn.disabled = true;
    try {
      await api('POST', '/api/login', { email: form.email.value, password: form.password.value });
      await loadMe(); const to = nextRoute || '/alumni'; nextRoute = null; location.hash = '#' + to;
    } catch (err) { showErr(msg, err); } finally { btn.disabled = false; }
  } },
    h('label', { for: 'l-email' }, 'Email'), h('input', { id: 'l-email', name: 'email', type: 'email', required: true, autocomplete: 'username' }),
    pwField('password', 'Password', 'current-password'), msg, h('button', { class: 'btn', type: 'submit' }, 'Log in'),
    h('p', { class: 'hint', style: 'margin-top:14px' }, 'Forgot your password? Ask the college admin to reset it from the Contact page.'));
  main.replaceChildren(h('div', { class: 'narrow' }, h('div', { class: 'page-title' }, h('h1', {}, 'Log in')), form, h('p', {}, 'New here? ', h('a', { href: '#/signup' }, 'Join the network'))), footer());
}

/* ---------- pages: alumni area ---------- */
async function directory() {
  let offset = 0, timer;
  const q = h('input', { type: 'search', placeholder: 'Search name, company, city…', 'aria-label': 'Search alumni' });
  const deg = h('select', { 'aria-label': 'Filter by degree' }, h('option', { value: '' }, 'All degrees'));
  const yr = h('select', { 'aria-label': 'Filter by year' }, h('option', { value: '' }, 'All years'));
  const list = h('ul', { class: 'list' }); const more = h('button', { class: 'btn ghost', hidden: true, onclick: () => load(false) }, 'Show more');
  const count = h('p', { class: 'meta' });
  async function load(reset) {
    if (reset) { offset = 0; list.replaceChildren(); }
    try {
      const r = await api('GET', `/api/alumni?q=${encodeURIComponent(q.value)}&degree=${encodeURIComponent(deg.value)}&year=${yr.value}&offset=${offset}`);
      if (deg.options.length === 1) { r.degrees.forEach((d) => deg.append(h('option', { value: d }, d))); r.years.forEach((y) => yr.append(h('option', { value: y }, y))); }
      r.alumni.forEach((a) => list.append(h('li', {}, h('a', { class: 'person', href: '#/alumni/' + a.id }, avatar(a.full_name, a.photo),
        h('div', { class: 'grow' }, h('b', {}, a.full_name), h('div', { class: 'sub' }, [a.degree, a.grad_year].filter(Boolean).join(', ')),
          h('div', { class: 'sub' }, a.job_role ? a.job_role + (a.company_name ? ' at ' + a.company_name : '') : a.status || ''))))));
      offset += r.alumni.length; more.hidden = offset >= r.total;
      count.textContent = r.total ? `${r.total} alumnae` : '';
      if (!r.total) list.replaceChildren(h('li', { class: 'empty' }, 'No alumni match your search. Try a shorter name or clear the filters.'));
    } catch (e) { list.replaceChildren(h('li', { class: 'msg err' }, e.message)); }
  }
  const go = () => { clearTimeout(timer); timer = setTimeout(() => load(true), 300); };
  q.addEventListener('input', go); deg.addEventListener('change', go); yr.addEventListener('change', go);
  main.replaceChildren(h('div', { class: 'wrap' }, h('div', { class: 'page-title' }, h('h1', {}, 'Alumni directory')), h('div', { class: 'tools' }, q, deg, yr), count, list, h('p', { style: 'text-align:center;margin:18px 0' }, more)), footer());
  load(true);
}

async function profile(id) {
  main.replaceChildren(h('div', { class: 'wrap' }, h('p', { class: 'meta', style: 'padding:30px 0' }, 'Loading…')));
  try {
    const p = await api('GET', '/api/alumni/' + id);
    const f = (k, v) => (v ? h('div', {}, h('dt', {}, k), h('dd', {}, v)) : null);
    main.replaceChildren(h('div', { class: 'wrap' },
      h('p', { style: 'margin:18px 0 0' }, h('a', { href: '#/alumni' }, '← All alumni')),
      h('div', { class: 'profile' }, avatar(p.full_name, p.photo, 'lg'), h('div', {}, h('h1', { style: 'margin:0' }, p.full_name), h('p', { class: 'lead', style: 'margin:4px 0 14px' }, [p.degree, p.grad_year].filter(Boolean).join(', ')),
        h('div', { class: 'row' }, state.user && state.user.id !== p.id ? h('a', { class: 'btn lamp', href: '#/chat/' + p.id }, 'Send message') : h('a', { class: 'btn', href: '#/me/edit' }, 'Edit my profile'),
          h('a', { class: 'btn ghost', href: 'mailto:' + p.email }, 'Email'), p.phone ? h('a', { class: 'btn ghost', href: 'tel:' + p.phone.replace(/[^\d+]/g, '') }, 'Call') : null,
          p.linkedin ? h('a', { class: 'btn ghost', href: p.linkedin, target: '_blank', rel: 'noopener noreferrer' }, 'LinkedIn') : null))),
      p.objective ? h('p', { class: 'prose' }, '“' + p.objective + '”') : null,
      h('dl', { class: 'facts' }, f('Status', p.status), f('Job role', p.job_role), f('Company', p.company_name), f('Company location', p.company_location), f('Studying at', p.institution_name), f('Course', p.course_name), f('Expected completion', p.completion_year), f('Details', p.other_specify), f('Lives in', p.location), f('Email', p.email), f('Phone', p.phone))), footer());
  } catch (e) { main.replaceChildren(h('div', { class: 'wrap' }, h('p', { class: 'msg err', style: 'margin-top:30px' }, e.message))); }
}

function me() {
  const u = state.user;
  const msg = h('div', { hidden: true });
  const pw = h('form', { class: 'form', hidden: true, onsubmit: async (e) => {
    e.preventDefault(); msg.hidden = true;
    try { await api('PUT', '/api/me/password', { current: pw.current.value, next: pw.next.value }); pw.reset(); pw.hidden = true; toast('Password changed.'); }
    catch (err) { showErr(msg, err); }
  } }, pwField('current', 'Current password', 'current-password'), pwField('next', 'New password (8+ characters)', 'new-password'), msg, h('button', { class: 'btn', type: 'submit' }, 'Change password'));
  main.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'profile' }, avatar(u.full_name, u.photo, 'lg'), h('div', {}, h('h1', { style: 'margin:0' }, u.full_name), h('p', { class: 'lead', style: 'margin:4px 0 14px' }, u.email),
      h('div', { class: 'row' }, h('a', { class: 'btn', href: '#/me/edit' }, 'Edit profile'), h('button', { class: 'btn ghost', onclick: () => { pw.hidden = !pw.hidden; } }, 'Change password'),
        h('button', { class: 'btn ghost', onclick: async () => { await api('POST', '/api/logout').catch(() => {}); state.user = null; state.unread = 0; renderNav(); location.hash = '#/'; toast('You are logged out.'); } }, 'Log out')))),
    h('div', { class: 'narrow', style: 'margin:0' }, pw),
    h('dl', { class: 'facts' }, [['Degree', u.degree], ['Graduated', u.grad_year], ['Status', u.status], ['Job role', u.job_role], ['Company', u.company_name], ['Lives in', u.location], ['Phone', u.phone], ['Goal', u.objective]].filter((x) => x[1]).map(([k, v]) => h('div', {}, h('dt', {}, k), h('dd', {}, v))))), footer());
}
function editProfile() {
  const form = profileForm(state.user, 'edit', async (data) => {
    await api('PUT', '/api/me', data); await loadMe(); toast('Profile saved.'); location.hash = '#/me';
  });
  main.replaceChildren(h('div', { class: 'narrow' }, h('div', { class: 'page-title' }, h('h1', {}, 'Edit profile')), form), footer());
}

/* ---------- chat ---------- */
async function chats() {
  const list = h('ul', { class: 'list' });
  main.replaceChildren(h('div', { class: 'wrap' }, h('div', { class: 'page-title row', style: 'justify-content:space-between' }, h('h1', {}, 'Chats'), h('a', { class: 'btn small lamp', href: '#/alumni' }, 'New chat')), list), footer());
  async function load() {
    try {
      const r = await api('GET', '/api/chats');
      list.replaceChildren(...(r.chats.length ? r.chats.map((c) => h('li', {}, h('a', { class: 'person', href: '#/chat/' + c.id }, avatar(c.full_name, c.photo),
        h('div', { class: 'grow' }, h('b', {}, c.full_name), h('div', { class: 'sub', style: c.unread ? 'font-weight:700;color:var(--text)' : '' }, (c.mine ? 'You: ' : '') + c.last)),
        h('span', { class: 'meta' }, fmtTime(c.at)), c.unread ? h('span', { class: 'dot', title: c.unread + ' unread' }) : null)))
        : [h('li', { class: 'empty' }, 'No chats yet. Open the alumni directory, pick someone and send a message.')]));
      await loadMe();
    } catch (e) { list.replaceChildren(h('li', { class: 'msg err' }, e.message)); }
  }
  load(); every(6000, load);
}

function chatShell({ title, sub, back, send, poll }) {
  const thread = h('div', { class: 'thread', role: 'log', 'aria-live': 'polite' });
  const ta = h('textarea', { rows: 1, maxlength: 1000, placeholder: 'Write a message', 'aria-label': 'Message' });
  const btn = h('button', { class: 'btn', type: 'submit' }, 'Send');
  const fine = matchMedia('(pointer:fine)').matches;
  let last = 0, busy = false;
  async function refresh() {
    if (busy) return; busy = true;
    try {
      const nearBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 120;
      const first = last === 0;
      const msgs = await poll(last);
      if (first && !msgs.length) thread.replaceChildren(h('p', { class: 'empty' }, 'No messages yet. Say hello.'));
      if (msgs.length) {
        if (first) thread.replaceChildren();
        msgs.forEach((m) => { thread.append(m.node); last = Math.max(last, m.id); });
        if (first || nearBottom) thread.scrollTop = thread.scrollHeight;
      }
    } catch (e) { if (!last) thread.replaceChildren(h('p', { class: 'msg err' }, e.message)); } finally { busy = false; }
  }
  const form = h('form', { class: 'composer', onsubmit: async (e) => {
    e.preventDefault(); const text = ta.value.trim(); if (!text) return;
    btn.disabled = true;
    try { await send(text); ta.value = ''; await refresh(); thread.scrollTop = thread.scrollHeight; } catch (err) { toast(err.message); } finally { btn.disabled = false; ta.focus(); }
  } }, ta, btn);
  ta.addEventListener('keydown', (e) => { if (fine && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); } });
  const head = h('header', {}, h('a', { class: 'back', href: back, 'aria-label': 'Back' }, '←'), title, sub);
  main.replaceChildren(h('div', { class: 'chat' }, head, thread, form));
  refresh(); every(3500, refresh);
  return { head };
}
const bubble = (m, who) => h('div', { class: 'bub' + (m.mine ? ' mine' : '') }, who && !m.mine ? h('span', { class: 'who' }, who) : null, m.body, h('time', { datetime: m.at }, fmtTime(m.at)));

function thread(id) {
  id = Number(id); let peerSet = false; let shell;
  shell = chatShell({
    title: h('div', {}, ''), sub: null, back: '#/chat',
    send: (text) => api('POST', '/api/messages', { to: id, body: text }),
    poll: async (after) => {
      const r = await api('GET', `/api/messages/${id}?after=${after}`);
      if (!peerSet) { peerSet = true; const head = document.querySelector('.chat header'); head.replaceChildren(h('a', { class: 'back', href: '#/chat', 'aria-label': 'Back' }, '←'), avatar(r.peer.full_name, r.peer.photo, 'sm'), h('a', { href: '#/alumni/' + id, style: 'font-weight:700;text-decoration:none;color:inherit' }, r.peer.full_name)); }
      if (r.messages.length && !after) { /* initial load also clears unread badge */ loadMe(); }
      return r.messages.map((m) => ({ id: m.id, node: bubble(m) }));
    },
  });
}
function group() {
  chatShell({
    title: h('b', {}, 'Alumni group chat'), sub: h('span', { class: 'meta' }, 'Everyone can read this'), back: '#/',
    send: (text) => api('POST', '/api/group', { body: text }),
    poll: async (after) => (await api('GET', `/api/group?after=${after}`)).messages.map((m) => ({ id: m.id, node: bubble(m, m.author.full_name) })),
  });
}

/* ---------- admin ---------- */
function admin() {
  if (!state.admin) {
    const msg = h('div', { hidden: true });
    const form = h('form', { class: 'form', onsubmit: async (e) => {
      e.preventDefault(); msg.hidden = true;
      try { await api('POST', '/api/admin/login', { username: form.username.value, password: form.password.value }); state.admin = true; admin(); }
      catch (err) { showErr(msg, err); }
    } }, h('label', { for: 'a-user' }, 'Admin username'), h('input', { id: 'a-user', name: 'username', required: true, autocomplete: 'username' }),
      pwField('password', 'Password', 'current-password'), msg, h('button', { class: 'btn', type: 'submit' }, 'Log in as admin'));
    return main.replaceChildren(h('div', { class: 'narrow' }, h('div', { class: 'page-title' }, h('h1', {}, 'Admin login')), form), footer());
  }
  const tabs = ['Approvals', 'Alumni', 'Reviews', 'Messages', 'Group chat', 'Account'];
  let cur = 0;
  const bar = h('div', { class: 'atabs', role: 'tablist' });
  const body = h('div', {});
  const counts = {};
  async function drawBar() {
    try { const o = await api('GET', '/api/admin/overview'); counts.Approvals = o.pending; counts.Reviews = o.reviews; counts.Messages = o.messages; } catch (e) { if (e.status === 401) { state.admin = false; return admin(); } }
    bar.replaceChildren(...tabs.map((t, i) => h('button', { role: 'tab', 'aria-selected': i === cur, onclick: () => { cur = i; drawBar(); draw(); } }, t, counts[t] ? h('span', { class: 'badge' }, counts[t]) : null)));
  }
  const refresh = () => { drawBar(); draw(); };
  const act = async (fn, okText) => { try { await fn(); if (okText) toast(okText); refresh(); } catch (e) { if (e.status === 401) { state.admin = false; return admin(); } toast(e.message); } };
  async function draw() {
    body.replaceChildren(h('p', { class: 'meta' }, 'Loading…'));
    try {
      const t = tabs[cur];
      if (t === 'Approvals') {
        const { pending } = await api('GET', '/api/admin/pending');
        if (!pending.length) return body.replaceChildren(h('p', { class: 'empty' }, 'No registrations are waiting for approval.'));
        const boxes = [];
        body.replaceChildren(h('div', { class: 'row' }, h('button', { class: 'btn lamp small', onclick: () => { const ids = boxes.filter((b) => b.checked).map((b) => Number(b.value)); if (!ids.length) return toast('Tick at least one registration.'); act(() => api('POST', '/api/admin/approve', { ids }), 'Approved.'); } }, 'Approve selected'),
          h('button', { class: 'btn ghost small', onclick: () => boxes.forEach((b) => { b.checked = true; }) }, 'Select all')),
          pending.map((p) => { const cb = h('input', { type: 'checkbox', value: p.id, 'aria-label': 'Select ' + p.full_name, style: 'width:22px;min-height:22px;height:22px' }); boxes.push(cb);
            return h('div', { class: 'item' }, h('div', { class: 'row', style: 'justify-content:flex-start' }, cb, avatar(p.full_name, p.photo), h('div', { class: 'grow', style: 'flex:1' }, h('h3', {}, p.full_name), h('div', { class: 'meta' }, `${p.degree}, ${p.grad_year}. ${p.status}${p.company_name ? ' at ' + p.company_name : ''}`), h('div', { class: 'meta' }, `${p.email}, ${p.phone}, ${p.location}`))),
              h('div', { class: 'row', style: 'margin-top:10px;justify-content:flex-end' }, h('button', { class: 'btn small', onclick: () => act(() => api('POST', '/api/admin/approve', { ids: [p.id] }), 'Approved.') }, 'Approve'),
                h('button', { class: 'btn small danger', onclick: () => confirm('Reject and delete this registration?') && act(() => api('POST', '/api/admin/reject', { ids: [p.id] }), 'Rejected.') }, 'Reject'))); }));
      } else if (t === 'Alumni') {
        const q = h('input', { type: 'search', placeholder: 'Search name, email, phone', 'aria-label': 'Search' }); const out = h('div', {}); let tm;
        const load = async () => { const { alumni } = await api('GET', '/api/admin/alumni?q=' + encodeURIComponent(q.value));
          out.replaceChildren(h('p', { class: 'meta' }, alumni.length + ' shown'), alumni.map((a) => h('div', { class: 'item' }, h('div', { class: 'row', style: 'justify-content:flex-start' }, avatar(a.full_name, a.photo), h('div', { style: 'flex:1;min-width:0' }, h('h3', {}, a.full_name), h('div', { class: 'meta' }, `${a.degree}, ${a.grad_year}`), h('div', { class: 'meta' }, `${a.email}, ${a.phone}`))),
            h('div', { class: 'row', style: 'margin-top:10px;justify-content:flex-end' }, h('button', { class: 'btn ghost small', onclick: async () => { if (!confirm('Create a temporary password for ' + a.full_name + '?')) return; try { const r = await api('POST', `/api/admin/alumni/${a.id}/reset-password`); prompt('Temporary password (share it privately, then ask her to change it):', r.temporary_password); } catch (e) { toast(e.message); } } }, 'Reset password'),
              h('button', { class: 'btn danger small', onclick: () => confirm('Remove ' + a.full_name + ' and all her messages? This cannot be undone.') && act(() => api('DELETE', '/api/admin/alumni/' + a.id), 'Removed.') }, 'Remove'))))); };
        q.addEventListener('input', () => { clearTimeout(tm); tm = setTimeout(load, 300); });
        body.replaceChildren(h('div', { class: 'row' }, h('div', { style: 'flex:1;min-width:200px' }, q), h('a', { class: 'btn ghost small', href: '/api/admin/export.csv', download: 'pkr-alumni.csv' }, 'Download CSV')), out); load();
      } else if (t === 'Reviews') {
        const { reviews: rs } = await api('GET', '/api/admin/reviews');
        body.replaceChildren(rs.length ? rs.map((r) => h('div', { class: 'item' }, h('div', { class: 'row' }, h('div', {}, stars(r.rating), ' ', h('b', {}, r.name), ' ', h('span', { class: 'tag' }, r.approved ? 'Published' : 'Waiting')), h('span', { class: 'meta' }, fmtDate(r.created_at))), r.review ? h('p', { style: 'margin:8px 0' }, r.review) : null,
          h('div', { class: 'row', style: 'justify-content:flex-end' }, r.approved ? null : h('button', { class: 'btn small', onclick: () => act(() => api('POST', `/api/admin/reviews/${r.id}/approve`), 'Published.') }, 'Publish'), h('button', { class: 'btn danger small', onclick: () => confirm('Delete this review?') && act(() => api('DELETE', '/api/admin/reviews/' + r.id), 'Deleted.') }, 'Delete')))) : h('p', { class: 'empty' }, 'No reviews yet.'));
      } else if (t === 'Messages') {
        const { messages } = await api('GET', '/api/admin/contacts');
        body.replaceChildren(messages.length ? messages.map((m) => h('div', { class: 'item' }, h('div', { class: 'row' }, h('div', {}, h('b', {}, m.name), ' ', h('a', { href: 'mailto:' + m.email }, m.email), ' ', m.done ? h('span', { class: 'tag' }, 'Done') : null), h('span', { class: 'meta' }, fmtTime(m.created_at))), h('p', { style: 'margin:8px 0;white-space:pre-wrap' }, m.message),
          h('div', { class: 'row', style: 'justify-content:flex-end' }, m.done ? null : h('button', { class: 'btn small', onclick: () => act(() => api('POST', `/api/admin/contacts/${m.id}/done`), 'Marked done.') }, 'Mark done'), h('button', { class: 'btn danger small', onclick: () => confirm('Delete this message?') && act(() => api('DELETE', '/api/admin/contacts/' + m.id), 'Deleted.') }, 'Delete')))) : h('p', { class: 'empty' }, 'No contact messages.'));
      } else if (t === 'Group chat') {
        const { messages } = await api('GET', '/api/admin/group');
        body.replaceChildren(messages.length ? messages.map((m) => h('div', { class: 'item' }, h('div', { class: 'row' }, h('b', {}, m.full_name || 'Removed user'), h('span', { class: 'meta' }, fmtTime(m.created_at))), h('p', { style: 'margin:6px 0;white-space:pre-wrap' }, m.body), h('div', { class: 'row', style: 'justify-content:flex-end' }, h('button', { class: 'btn danger small', onclick: () => act(() => api('DELETE', '/api/admin/group/' + m.id), 'Message deleted.') }, 'Delete')))) : h('p', { class: 'empty' }, 'No group messages.'));
      } else {
        const msg = h('div', { hidden: true });
        const f = h('form', { class: 'form', onsubmit: async (e) => { e.preventDefault(); msg.hidden = true; try { await api('PUT', '/api/admin/password', { current: f.current.value, next: f.next.value }); f.reset(); toast('Admin password changed.'); } catch (err) { showErr(msg, err); } } },
          pwField('current', 'Current password', 'current-password'), pwField('next', 'New password (10+ characters)', 'new-password'), msg, h('button', { class: 'btn', type: 'submit' }, 'Change admin password'));
        body.replaceChildren(h('div', { class: 'narrow', style: 'margin:0' }, f, h('button', { class: 'btn ghost', onclick: async () => { await api('POST', '/api/admin/logout').catch(() => {}); state.admin = false; admin(); } }, 'Log out of admin')));
      }
    } catch (e) { if (e.status === 401) { state.admin = false; return admin(); } body.replaceChildren(h('p', { class: 'msg err' }, e.message)); }
  }
  main.replaceChildren(h('div', { class: 'wrap' }, h('div', { class: 'page-title' }, h('h1', {}, 'Admin panel')), bar, body), footer());
  drawBar(); draw();
}

/* ---------- router ---------- */
const routes = [
  [/^\/$/, home], [/^\/about$/, about], [/^\/gallery$/, gallery], [/^\/contact$/, contact], [/^\/reviews$/, reviews], [/^\/install$/, install],
  [/^\/signup$/, signup], [/^\/login$/, login], [/^\/admin$/, admin],
  [/^\/alumni$/, directory, 1], [/^\/alumni\/(\d+)$/, profile, 1], [/^\/me$/, me, 1], [/^\/me\/edit$/, editProfile, 1],
  [/^\/chat$/, chats, 1], [/^\/chat\/(\d+)$/, thread, 1], [/^\/group$/, group, 1],
];
const TITLES = { '': 'Home', about: 'About', gallery: 'Gallery', contact: 'Contact', reviews: 'Reviews', install: 'Install', signup: 'Join', login: 'Log in', admin: 'Admin', alumni: 'Alumni', me: 'My profile', chat: 'Chats', group: 'Group chat' };
function render() {
  cleanups.forEach((f) => f()); cleanups = [];
  const path = location.hash.slice(1) || '/';
  const hit = routes.find(([re]) => re.test(path));
  document.getElementById('tabs').style.display = '';
  if (!hit) { main.replaceChildren(h('div', { class: 'narrow empty' }, h('h1', {}, 'Page not found'), h('a', { class: 'btn', href: '#/' }, 'Go to home'))); return renderNav(); }
  if (hit[2] && !state.user) { nextRoute = path; location.hash = '#/login'; return; }
  document.title = (TITLES[path.split('/')[1]] || 'PKR Alumni') + ' | PKR Alumni';
  renderNav();
  hit[1](...(hit[0].exec(path).slice(1)));
  if (!/^\/(chat\/|group)/.test(path)) scrollTo(0, 0);
  main.focus({ preventScroll: true });
}
addEventListener('hashchange', render);

(async function boot() {
  await loadMe();
  render();
  setInterval(() => { if (!document.hidden && state.user) loadMe(); }, 30000);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
})();
})();
