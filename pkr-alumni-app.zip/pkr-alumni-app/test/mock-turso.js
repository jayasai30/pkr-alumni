// Minimal stand-in for Turso's /v2/pipeline HTTP API, backed by local SQLite. Used only to test db.js.
const http = require('node:http');
const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(process.argv[3] || ':memory:');
http.createServer((req, res) => {
  let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
    if (req.headers.authorization !== 'Bearer testtoken') { res.writeHead(401); return res.end('{"error":"auth"}'); }
    const out = { baton: null, base_url: null, results: [] };
    for (const r of JSON.parse(b).requests) {
      if (r.type === 'close') { out.results.push({ type: 'ok', response: { type: 'close' } }); continue; }
      try {
        const args = r.stmt.args.map((a) => (a.type === 'null' ? null : a.type === 'integer' ? Number(a.value) : a.value));
        const st = db.prepare(r.stmt.sql);
        if (/^\s*(select|pragma|with)/i.test(r.stmt.sql)) {
          const rows = st.all(...args); const cols = rows[0] ? Object.keys(rows[0]) : st.columns().map((c) => c.name);
          out.results.push({ type: 'ok', response: { type: 'execute', result: { cols: cols.map((name) => ({ name })), rows: rows.map((o) => cols.map((c) => o[c] === null ? { type: 'null' } : typeof o[c] === 'number' ? { type: 'integer', value: String(o[c]) } : { type: 'text', value: String(o[c]) })), affected_row_count: 0, last_insert_rowid: null } } });
        } else {
          const x = st.run(...args);
          out.results.push({ type: 'ok', response: { type: 'execute', result: { cols: [], rows: [], affected_row_count: Number(x.changes), last_insert_rowid: String(x.lastInsertRowid) } } });
        }
      } catch (e) { out.results.push({ type: 'error', error: { message: e.message } }); }
    }
    res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(out));
  });
}).listen(Number(process.argv[2]) || 8099, '127.0.0.1');
