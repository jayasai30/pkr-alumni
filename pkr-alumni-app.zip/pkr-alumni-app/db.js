'use strict';
// Database layer. Two interchangeable backends with the same tiny API:
//   - local SQLite file (Node's built-in node:sqlite)  -> default, zero setup
//   - Turso (libSQL over HTTPS, free tier, persistent) -> set TURSO_URL + TURSO_TOKEN
// API: await db.all(sql, args) / db.get(sql, args) / db.run(sql, args) -> {changes,lastId}

const fs = require('node:fs');
const path = require('node:path');

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS alumni (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    location TEXT,
    degree TEXT,
    grad_year INTEGER,
    status TEXT,
    job_role TEXT,
    company_name TEXT,
    company_location TEXT,
    institution_name TEXT,
    course_name TEXT,
    completion_year INTEGER,
    other_specify TEXT,
    phone TEXT,
    email TEXT NOT NULL COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    objective TEXT,
    linkedin TEXT,
    photo TEXT,
    photo_v INTEGER NOT NULL DEFAULT 0,
    approved INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
    approved_at TEXT
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_alumni_email ON alumni(email)`,
  `CREATE INDEX IF NOT EXISTS idx_alumni_approved ON alumni(approved, full_name)`,
  `CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    body TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_msg_pair ON messages(sender_id, receiver_id, id)`,
  `CREATE INDEX IF NOT EXISTS idx_msg_recv ON messages(receiver_id, is_read)`,
  `CREATE TABLE IF NOT EXISTS group_chat (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alumni_id INTEGER NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
  )`,
  `CREATE TABLE IF NOT EXISTS ratings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    rating INTEGER NOT NULL,
    review TEXT,
    approved INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
  )`,
  `CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    message TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
  )`,
  `CREATE TABLE IF NOT EXISTS admin (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    pw_hash TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)`,
];

const clean = (args) => (args || []).map((a) => (a === undefined ? null : typeof a === 'boolean' ? (a ? 1 : 0) : a));

function localBackend(file) {
  const { DatabaseSync } = require('node:sqlite');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const d = new DatabaseSync(file);
  d.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
  return {
    kind: 'sqlite',
    async exec(sql, args) {
      const st = d.prepare(sql);
      if (/^\s*(select|pragma|with)/i.test(sql)) {
        return { rows: st.all(...clean(args)).map((r) => ({ ...r })), changes: 0, lastId: 0 };
      }
      const r = st.run(...clean(args));
      return { rows: [], changes: Number(r.changes), lastId: Number(r.lastInsertRowid) };
    },
  };
}

function tursoBackend(url, token) {
  const base = url.replace(/^libsql:\/\//, 'https://').replace(/\/+$/, '');
  const enc = (v) => {
    if (v === null || v === undefined) return { type: 'null' };
    if (typeof v === 'number') return Number.isInteger(v) ? { type: 'integer', value: String(v) } : { type: 'float', value: v };
    if (typeof v === 'bigint') return { type: 'integer', value: String(v) };
    return { type: 'text', value: String(v) };
  };
  const dec = (c) => {
    if (!c || c.type === 'null') return null;
    if (c.type === 'integer') return Number(c.value);
    if (c.type === 'float') return Number(c.value);
    return c.value;
  };
  return {
    kind: 'turso',
    async exec(sql, args) {
      const res = await fetch(base + '/v2/pipeline', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requests: [{ type: 'execute', stmt: { sql, args: clean(args).map(enc) } }, { type: 'close' }],
        }),
      });
      if (!res.ok) throw new Error('Turso HTTP ' + res.status + ': ' + (await res.text()).slice(0, 200));
      const data = await res.json();
      const first = data.results && data.results[0];
      if (!first || first.type === 'error') throw new Error('Turso error: ' + (first && first.error && first.error.message));
      const r = first.response.result;
      const cols = r.cols.map((c) => c.name);
      return {
        rows: r.rows.map((row) => Object.fromEntries(row.map((c, i) => [cols[i], dec(c)]))),
        changes: r.affected_row_count || 0,
        lastId: r.last_insert_rowid ? Number(r.last_insert_rowid) : 0,
      };
    },
  };
}

async function open() {
  const be = process.env.TURSO_URL
    ? tursoBackend(process.env.TURSO_URL, process.env.TURSO_TOKEN || '')
    : localBackend(process.env.DB_FILE || path.join(__dirname, 'data', 'alumni.db'));
  const db = {
    kind: be.kind,
    all: async (sql, args) => (await be.exec(sql, args)).rows,
    get: async (sql, args) => (await be.exec(sql, args)).rows[0] || null,
    run: async (sql, args) => {
      const r = await be.exec(sql, args);
      return { changes: r.changes, lastId: r.lastId };
    },
  };
  for (const s of SCHEMA) await db.run(s);
  return db;
}

module.exports = { open };
