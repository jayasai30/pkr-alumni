'use strict';
// PKR Alumni — zero-dependency Node server (needs Node 22.5+).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const { open } = require('./db');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC = path.join(__dirname, 'public');
const IS_PROD = process.env.NODE_ENV === 'production';
const SESSION_DAYS = 30;
const ADMIN_SESSION_HOURS = 12;

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);

/* ---------------- small helpers ---------------- */
const b64u = (b) => Buffer.from(b).toString('base64url');
const nowIso = () => new Date().toISOString().replace(/\.\d+Z$/, 'Z');

function scryptAsync(pw, salt) {
  return new Promise((res, rej) => crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => (e ? rej(e) : res(k))));
}
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  return `scrypt$${salt.toString('base64')}$${(await scryptAsync(pw, salt)).toString('base64')}`;
}
async function verifyPassword(pw, stored) {
  const [alg, s, h] = String(stored || '').split('$');
  if (alg !== 'scrypt' || !s || !h) return false;
  const want = Buffer.from(h, 'base64');
  const got = await scryptAsync(pw, Buffer.from(s, 'base64'));
  return want.length === got.length && crypto.timingSafeEqual(want, got);
}

/* ---------------- validation ---------------- */
function str(v, max, { required = false, label = 'Field' } = {}) {
  const s = typeof v === 'string' ? v.trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '') : '';
  if (required && !s) throw bad(`${label} is required.`);
  if (s.length > max) throw bad(`${label} is too long (max ${max} characters).`);
  return s;
}
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function email(v) {
  const s = str(v, 120, { required: true, label: 'Email' }).toLowerCase();
  if (!EMAIL_RE.test(s)) throw bad('Please enter a valid email address.');
  return s;
}
function phone(v) {
  const s = str(v, 20, { required: true, label: 'Phone number' });
  const digits = s.replace(/\D/g, '');
  if (!/^[+\d][\d\s\-()]{5,19}$/.test(s) || digits.length < 7 || digits.length > 15) throw bad('Please enter a valid phone number.');
  return s;
}
function year(v, label, required) {
  if (v === '' || v === null || v === undefined) {
    if (required) throw bad(`${label} is required.`);
    return null;
  }
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1950 || n > new Date().getFullYear() + 8) throw bad(`${label} is not a valid year.`);
  return n;
}
function url(v) {
  const s = str(v, 300, { label: 'LinkedIn URL' });
  if (!s) return '';
  let u;
  try { u = new URL(s); } catch { throw bad('LinkedIn link must be a full URL starting with https://'); }
  if (!/^https?:$/.test(u.protocol)) throw bad('LinkedIn link must start with https://');
  return u.href;
}
function password(v) {
  if (typeof v !== 'string' || v.length < 8) throw bad('Password must be at least 8 characters.');
  if (v.length > 200) throw bad('Password is too long.');
  return v;
}
const PHOTO_MAX = 450 * 1024; // bytes after base64 decode
function photo(v, required) {
  if (v === undefined || v === null || v === '') {
    if (required) throw bad('Please upload a profile photo.');
    return null;
  }
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(v));
  if (!m) throw bad('Photo must be a JPG, PNG or WebP image.');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > PHOTO_MAX) throw bad('Photo is too large (max ~450 KB). Try a smaller picture.');
  const hex = buf.subarray(0, 12).toString('hex');
  const ok = (m[1] === 'image/jpeg' && hex.startsWith('ffd8ff')) ||
    (m[1] === 'image/png' && hex.startsWith('89504e47')) ||
    (m[1] === 'image/webp' && hex.startsWith('52494646') && hex.slice(16, 24) === '57454250');
  if (!ok) throw bad('That file is not a valid image.');
  return String(v);
}

/* ---------------- rate limiting (in memory, per IP) ---------------- */
const hits = new Map();
function limit(ip, bucket, max, windowMs) {
  const key = bucket + '|' + ip;
  const t = Date.now();
  const arr = (hits.get(key) || []).filter((x) => t - x < windowMs);
  if (arr.length >= max) { hits.set(key, arr); throw new HttpError(429, 'Too many attempts. Please wait a few minutes and try again.'); }
  arr.push(t);
  hits.set(key, arr);
}
setInterval(() => { const t = Date.now(); for (const [k, a] of hits) if (!a.length || t - a[a.length - 1] > 3600e3) hits.delete(k); }, 600e3).unref();

/* ---------------- app ---------------- */
async function main() {
  const db = await open();
  if (IS_PROD && db.kind === 'sqlite' && !process.env.DB_FILE) {
    console.warn('\n!! WARNING: running in production with a local database file. On free hosts the disk is wiped on every restart,');
    console.warn('!! so ALL registrations and chats would be lost. Set TURSO_URL and TURSO_TOKEN (see README) to keep data permanently.\n');
  }

  // --- secrets & first admin ---
  let secret = process.env.SESSION_SECRET;
  if (!secret) {
    const row = await db.get(`SELECT v FROM settings WHERE k='session_secret'`);
    if (row) secret = row.v;
    else {
      secret = crypto.randomBytes(32).toString('hex');
      await db.run(`INSERT INTO settings(k,v) VALUES('session_secret',?)`, [secret]);
    }
  }
  const adminCount = await db.get('SELECT COUNT(*) c FROM admin');
  if (!adminCount.c) {
    const user = (process.env.ADMIN_USER || 'admin').trim();
    let pw = process.env.ADMIN_PASSWORD;
    let generated = false;
    if (!pw) { pw = crypto.randomBytes(9).toString('base64url'); generated = true; }
    await db.run('INSERT INTO admin(username,pw_hash) VALUES(?,?)', [user, await hashPassword(pw)]);
    console.log('\n=== First admin account created ===');
    console.log('  username: ' + user);
    if (generated) console.log('  password: ' + pw + '   <-- shown once. Log in and change it (Admin > Account).');
    else console.log('  password: (taken from ADMIN_PASSWORD)');
    console.log('===================================\n');
  }

  // --- signed session tokens ---
  const sign = (p) => crypto.createHmac('sha256', secret).update(p).digest('base64url');
  function makeToken(payload, ttlMs) {
    const p = b64u(JSON.stringify({ ...payload, e: Date.now() + ttlMs }));
    return p + '.' + sign(p);
  }
  function readToken(t) {
    if (!t || typeof t !== 'string') return null;
    const [p, s] = t.split('.');
    if (!p || !s) return null;
    const want = Buffer.from(sign(p));
    const got = Buffer.from(s);
    if (want.length !== got.length || !crypto.timingSafeEqual(want, got)) return null;
    try {
      const o = JSON.parse(Buffer.from(p, 'base64url').toString());
      return o.e > Date.now() ? o : null;
    } catch { return null; }
  }
  const parseCookies = (h) => Object.fromEntries((h || '').split(';').map((c) => c.trim().split(/=(.*)/s).slice(0, 2)).filter((x) => x[0]));
  const setCookie = (ctx, name, val, maxAgeSec) => {
    const secure = ctx.https ? '; Secure' : '';
    ctx.cookies.push(`${name}=${val}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure}`);
  };

  /* ---------------- router ---------------- */
  const routes = [];
  const route = (method, pattern, opts, handler) => {
    if (typeof opts === 'function') { handler = opts; opts = {}; }
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, auth: opts.auth || null, handler });
  };

  const photoUrl = (r) => (r.photo_v ? `/api/photo/${r.id}?v=${r.photo_v}` : null);
  const publicCard = (r) => ({
    id: r.id, full_name: r.full_name, degree: r.degree, grad_year: r.grad_year, job_role: r.job_role,
    company_name: r.company_name, location: r.location, status: r.status, photo: photoUrl(r),
  });
  const PROFILE_COLS = `id, full_name, location, degree, grad_year, status, job_role, company_name, company_location,
    institution_name, course_name, completion_year, other_specify, phone, email, objective, linkedin, photo_v, approved, created_at`;
  const fullProfile = (r) => ({ ...r, photo: photoUrl(r), photo_v: undefined });

  /* ===== public ===== */
  route('GET', '/healthz', async () => ({ ok: true, db: db.kind }));

  route('GET', '/api/stats', async () => {
    const a = await db.get('SELECT COUNT(*) c FROM alumni WHERE approved=1');
    const r = await db.get('SELECT COUNT(*) c, AVG(rating) avg FROM ratings WHERE approved=1');
    return { alumni: a.c, reviews: r.c, rating: r.avg ? Math.round(r.avg * 10) / 10 : null };
  });

  route('GET', '/api/ratings', async () => {
    const rows = await db.all('SELECT id, name, rating, review, created_at FROM ratings WHERE approved=1 ORDER BY id DESC LIMIT 50');
    const s = await db.get('SELECT COUNT(*) c, AVG(rating) avg FROM ratings WHERE approved=1');
    return { reviews: rows, count: s.c, average: s.avg ? Math.round(s.avg * 10) / 10 : null };
  });

  route('POST', '/api/ratings', async (ctx) => {
    limit(ctx.ip, 'rating', 5, 3600e3);
    const b = ctx.body;
    const rating = Number(b.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw bad('Please choose 1 to 5 stars.');
    const name = str(b.name, 60, { required: true, label: 'Name' });
    const em = b.email ? email(b.email) : '';
    const review = str(b.review, 600, { label: 'Review' });
    await db.run('INSERT INTO ratings(name,email,rating,review,approved) VALUES(?,?,?,?,0)', [name, em, rating, review]);
    return { ok: true, message: 'Thank you! Your review will appear once the admin approves it.' };
  });

  route('POST', '/api/contact', async (ctx) => {
    limit(ctx.ip, 'contact', 5, 3600e3);
    const b = ctx.body;
    const name = str(b.name, 80, { required: true, label: 'Name' });
    const em = email(b.email);
    const message = str(b.message, 2000, { required: true, label: 'Message' });
    await db.run('INSERT INTO contact_messages(name,email,message) VALUES(?,?,?)', [name, em, message]);
    sendMail(process.env.CONTACT_NOTIFY_TO, `New contact message from ${name}`, `${name} <${em}>\n\n${message}`);
    return { ok: true, message: 'Message sent. The college office will get back to you.' };
  });

  route('POST', '/api/register', async (ctx) => {
    limit(ctx.ip, 'register', 5, 3600e3);
    const b = ctx.body;
    const status = str(b.status, 30, { required: true, label: 'Current status' });
    if (!['Employed', 'Unemployed', 'Higher Education', 'Other'].includes(status)) throw bad('Please choose a valid current status.');
    const rec = {
      full_name: str(b.full_name, 80, { required: true, label: 'Full name' }),
      location: str(b.location, 100, { required: true, label: 'Location' }),
      degree: str(b.degree, 80, { required: true, label: 'Education' }),
      grad_year: year(b.grad_year, 'Year of graduation', true),
      status,
      job_role: str(b.job_role, 80), company_name: str(b.company_name, 100), company_location: str(b.company_location, 100),
      institution_name: str(b.institution_name, 120), course_name: str(b.course_name, 100),
      completion_year: year(b.completion_year, 'Completion year', false),
      other_specify: str(b.other_specify, 150),
      phone: phone(b.phone), email: email(b.email),
      objective: str(b.objective, 600), linkedin: url(b.linkedin),
    };
    const pw = password(b.password);
    const ph = photo(b.photo, true);
    const dupe = await db.get('SELECT id FROM alumni WHERE email=? OR phone=?', [rec.email, rec.phone]);
    if (dupe) throw new HttpError(409, 'An account with this email or phone number already exists.');
    const cols = Object.keys(rec);
    await db.run(
      `INSERT INTO alumni(${cols.join(',')}, password_hash, photo, photo_v, approved) VALUES(${cols.map(() => '?').join(',')},?,?,1,0)`,
      [...cols.map((c) => rec[c]), await hashPassword(pw), ph],
    );
    sendMail(process.env.CONTACT_NOTIFY_TO, 'New alumni registration awaiting approval', `${rec.full_name} (${rec.email}) registered. Review it in the Admin panel.`);
    return { ok: true, message: 'Registration submitted! You can log in once the admin approves your account.' };
  });

  route('POST', '/api/login', async (ctx) => {
    limit(ctx.ip, 'login', 10, 15 * 60e3);
    const em = str(ctx.body.email, 120).toLowerCase();
    const pw = typeof ctx.body.password === 'string' ? ctx.body.password : '';
    const row = await db.get('SELECT id, password_hash, approved FROM alumni WHERE email=?', [em]);
    // always run a hash to keep timing similar
    const ok = await verifyPassword(pw, row ? row.password_hash : 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$AAAA');
    if (!row || !ok) throw new HttpError(401, 'Invalid email or password.');
    if (!row.approved) throw new HttpError(403, 'Your registration is still waiting for admin approval.');
    setCookie(ctx, 'sid', makeToken({ u: row.id }, SESSION_DAYS * 86400e3), SESSION_DAYS * 86400);
    return { ok: true };
  });

  route('POST', '/api/logout', async (ctx) => {
    setCookie(ctx, 'sid', '', 0);
    return { ok: true };
  });

  /* ===== alumni (logged in) ===== */
  route('GET', '/api/me', async (ctx) => {
    const sess = readToken(ctx.cookies_in.sid);
    const adminSess = readToken(ctx.cookies_in.aid);
    let user = null, unread = 0;
    if (sess && sess.u) {
      const r = await db.get(`SELECT ${PROFILE_COLS} FROM alumni WHERE id=? AND approved=1`, [sess.u]);
      if (r) {
        user = fullProfile(r);
        unread = (await db.get('SELECT COUNT(*) c FROM messages WHERE receiver_id=? AND is_read=0', [r.id])).c;
      }
    }
    return { user, unread, admin: !!(adminSess && adminSess.a) };
  });

  route('PUT', '/api/me', { auth: 'user' }, async (ctx) => {
    const b = ctx.body;
    const status = str(b.status, 30, { required: true, label: 'Current status' });
    if (!['Employed', 'Unemployed', 'Higher Education', 'Other'].includes(status)) throw bad('Please choose a valid current status.');
    const em = email(b.email), ph = phone(b.phone);
    const dupe = await db.get('SELECT id FROM alumni WHERE (email=? OR phone=?) AND id<>?', [em, ph, ctx.user.id]);
    if (dupe) throw new HttpError(409, 'Another account already uses that email or phone number.');
    const newPhoto = photo(b.photo, false);
    await db.run(
      `UPDATE alumni SET full_name=?, location=?, degree=?, grad_year=?, status=?, job_role=?, company_name=?, company_location=?,
        institution_name=?, course_name=?, completion_year=?, other_specify=?, phone=?, email=?, objective=?, linkedin=? WHERE id=?`,
      [
        str(b.full_name, 80, { required: true, label: 'Full name' }), str(b.location, 100, { required: true, label: 'Location' }),
        str(b.degree, 80, { required: true, label: 'Education' }), year(b.grad_year, 'Year of graduation', true), status,
        str(b.job_role, 80), str(b.company_name, 100), str(b.company_location, 100), str(b.institution_name, 120),
        str(b.course_name, 100), year(b.completion_year, 'Completion year', false), str(b.other_specify, 150),
        ph, em, str(b.objective, 600), url(b.linkedin), ctx.user.id,
      ],
    );
    if (newPhoto) await db.run('UPDATE alumni SET photo=?, photo_v=photo_v+1 WHERE id=?', [newPhoto, ctx.user.id]);
    return { ok: true };
  });

  route('PUT', '/api/me/password', { auth: 'user' }, async (ctx) => {
    limit(ctx.ip, 'pwchange', 10, 3600e3);
    const row = await db.get('SELECT password_hash FROM alumni WHERE id=?', [ctx.user.id]);
    if (!(await verifyPassword(String(ctx.body.current || ''), row.password_hash))) throw new HttpError(403, 'Current password is incorrect.');
    await db.run('UPDATE alumni SET password_hash=? WHERE id=?', [await hashPassword(password(ctx.body.next)), ctx.user.id]);
    return { ok: true };
  });

  route('GET', '/api/photo/:id', { auth: 'any' }, async (ctx) => {
    const r = await db.get('SELECT photo, approved FROM alumni WHERE id=?', [Number(ctx.params.id)]);
    if (!r || !r.photo) throw new HttpError(404, 'No photo');
    if (!r.approved && !ctx.admin) throw new HttpError(404, 'No photo');
    const m = /^data:(image\/[a-z]+);base64,(.+)$/s.exec(r.photo);
    ctx.raw = { type: m[1], body: Buffer.from(m[2], 'base64'), cache: 'private, max-age=31536000, immutable' };
  });

  route('GET', '/api/alumni', { auth: 'user' }, async (ctx) => {
    const q = (ctx.query.get('q') || '').trim().slice(0, 60);
    const degree = (ctx.query.get('degree') || '').slice(0, 80);
    const yr = Number(ctx.query.get('year')) || 0;
    const offset = Math.max(0, Number(ctx.query.get('offset')) || 0);
    const where = ['approved=1'], args = [];
    if (q) {
      const like = '%' + q.replace(/[%_\\]/g, (c) => '\\' + c) + '%';
      where.push(`(full_name LIKE ? ESCAPE '\\' OR job_role LIKE ? ESCAPE '\\' OR company_name LIKE ? ESCAPE '\\' OR location LIKE ? ESCAPE '\\')`);
      args.push(like, like, like, like);
    }
    if (degree) { where.push('degree=?'); args.push(degree); }
    if (yr) { where.push('grad_year=?'); args.push(yr); }
    const W = where.join(' AND ');
    const total = (await db.get(`SELECT COUNT(*) c FROM alumni WHERE ${W}`, args)).c;
    const rows = await db.all(
      `SELECT id, full_name, degree, grad_year, job_role, company_name, location, status, photo_v FROM alumni WHERE ${W} ORDER BY full_name COLLATE NOCASE LIMIT 24 OFFSET ?`,
      [...args, offset],
    );
    const filters = await db.all('SELECT DISTINCT degree FROM alumni WHERE approved=1 AND degree IS NOT NULL ORDER BY degree');
    const years = await db.all('SELECT DISTINCT grad_year FROM alumni WHERE approved=1 AND grad_year IS NOT NULL ORDER BY grad_year DESC');
    return { total, alumni: rows.map(publicCard), degrees: filters.map((f) => f.degree), years: years.map((y) => y.grad_year) };
  });

  route('GET', '/api/alumni/:id', { auth: 'user' }, async (ctx) => {
    const r = await db.get(`SELECT ${PROFILE_COLS} FROM alumni WHERE id=? AND approved=1`, [Number(ctx.params.id)]);
    if (!r) throw new HttpError(404, 'Alumni not found.');
    const p = fullProfile(r);
    delete p.created_at; delete p.approved;
    return p;
  });

  /* --- private chat --- */
  route('GET', '/api/chats', { auth: 'user' }, async (ctx) => {
    const me = ctx.user.id;
    const rows = await db.all(
      `SELECT m.id, m.sender_id, m.body, m.created_at, a.id AS other_id, a.full_name, a.photo_v
       FROM messages m
       JOIN (SELECT CASE WHEN sender_id=? THEN receiver_id ELSE sender_id END AS other, MAX(id) AS last_id
             FROM messages WHERE sender_id=? OR receiver_id=? GROUP BY other) l ON m.id=l.last_id
       JOIN alumni a ON a.id=l.other AND a.approved=1
       ORDER BY m.id DESC LIMIT 100`, [me, me, me]);
    const unread = await db.all('SELECT sender_id, COUNT(*) c FROM messages WHERE receiver_id=? AND is_read=0 GROUP BY sender_id', [me]);
    const um = Object.fromEntries(unread.map((u) => [u.sender_id, u.c]));
    return {
      chats: rows.map((r) => ({
        id: r.other_id, full_name: r.full_name, photo: photoUrl({ id: r.other_id, photo_v: r.photo_v }),
        last: r.body.slice(0, 80), mine: r.sender_id === me, at: r.created_at, unread: um[r.other_id] || 0,
      })),
    };
  });

  route('GET', '/api/messages/:id', { auth: 'user' }, async (ctx) => {
    const me = ctx.user.id, other = Number(ctx.params.id);
    const after = Number(ctx.query.get('after')) || 0;
    const peer = await db.get('SELECT id, full_name, photo_v FROM alumni WHERE id=? AND approved=1', [other]);
    if (!peer) throw new HttpError(404, 'Alumni not found.');
    const rows = await db.all(
      `SELECT * FROM (SELECT id, sender_id, body, created_at FROM messages
         WHERE ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) AND id>? ORDER BY id DESC LIMIT 200) ORDER BY id ASC`,
      [me, other, other, me, after]);
    await db.run('UPDATE messages SET is_read=1 WHERE receiver_id=? AND sender_id=? AND is_read=0', [me, other]);
    return { peer: { id: peer.id, full_name: peer.full_name, photo: photoUrl(peer) }, messages: rows.map((m) => ({ id: m.id, mine: m.sender_id === me, body: m.body, at: m.created_at })) };
  });

  route('POST', '/api/messages', { auth: 'user' }, async (ctx) => {
    limit(ctx.ip + ':' + ctx.user.id, 'msg', 40, 60e3);
    const to = Number(ctx.body.to);
    const body = str(ctx.body.body, 1000, { required: true, label: 'Message' });
    if (!to || to === ctx.user.id) throw bad('Choose someone else to message.');
    const peer = await db.get('SELECT id FROM alumni WHERE id=? AND approved=1', [to]);
    if (!peer) throw new HttpError(404, 'Alumni not found.');
    const r = await db.run('INSERT INTO messages(sender_id,receiver_id,body) VALUES(?,?,?)', [ctx.user.id, to, body]);
    return { ok: true, id: r.lastId };
  });

  /* --- group chat --- */
  route('GET', '/api/group', { auth: 'user' }, async (ctx) => {
    const after = Number(ctx.query.get('after')) || 0;
    const rows = await db.all(
      `SELECT * FROM (SELECT g.id, g.alumni_id, g.body, g.created_at, a.full_name, a.photo_v FROM group_chat g
        JOIN alumni a ON a.id=g.alumni_id WHERE g.id>? ORDER BY g.id DESC LIMIT 100) ORDER BY id ASC`, [after]);
    return {
      messages: rows.map((m) => ({
        id: m.id, body: m.body, at: m.created_at, mine: m.alumni_id === ctx.user.id,
        author: { id: m.alumni_id, full_name: m.full_name, photo: photoUrl({ id: m.alumni_id, photo_v: m.photo_v }) },
      })),
    };
  });
  route('POST', '/api/group', { auth: 'user' }, async (ctx) => {
    limit(ctx.ip + ':' + ctx.user.id, 'grp', 30, 60e3);
    const body = str(ctx.body.body, 600, { required: true, label: 'Message' });
    const r = await db.run('INSERT INTO group_chat(alumni_id,body) VALUES(?,?)', [ctx.user.id, body]);
    return { ok: true, id: r.lastId };
  });

  /* ===== admin ===== */
  route('POST', '/api/admin/login', async (ctx) => {
    limit(ctx.ip, 'adminlogin', 8, 15 * 60e3);
    const u = str(ctx.body.username, 60), pw = typeof ctx.body.password === 'string' ? ctx.body.password : '';
    const row = await db.get('SELECT id, pw_hash FROM admin WHERE username=?', [u]);
    const ok = await verifyPassword(pw, row ? row.pw_hash : 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$AAAA');
    if (!row || !ok) throw new HttpError(401, 'Invalid admin username or password.');
    setCookie(ctx, 'aid', makeToken({ a: row.id }, ADMIN_SESSION_HOURS * 3600e3), ADMIN_SESSION_HOURS * 3600);
    return { ok: true };
  });
  route('POST', '/api/admin/logout', async (ctx) => { setCookie(ctx, 'aid', '', 0); return { ok: true }; });

  route('GET', '/api/admin/overview', { auth: 'admin' }, async () => {
    const one = async (sql) => (await db.get(sql)).c;
    return {
      pending: await one('SELECT COUNT(*) c FROM alumni WHERE approved=0'),
      alumni: await one('SELECT COUNT(*) c FROM alumni WHERE approved=1'),
      reviews: await one('SELECT COUNT(*) c FROM ratings WHERE approved=0'),
      messages: await one('SELECT COUNT(*) c FROM contact_messages WHERE done=0'),
    };
  });

  route('GET', '/api/admin/pending', { auth: 'admin' }, async () => ({
    pending: (await db.all(`SELECT ${PROFILE_COLS} FROM alumni WHERE approved=0 ORDER BY id`)).map(fullProfile),
  }));

  const ids = (v) => {
    if (!Array.isArray(v) || !v.length || v.length > 200) throw bad('Select at least one item.');
    const out = v.map(Number);
    if (out.some((n) => !Number.isInteger(n) || n < 1)) throw bad('Invalid selection.');
    return out;
  };
  const marks = (a) => a.map(() => '?').join(',');

  route('POST', '/api/admin/approve', { auth: 'admin' }, async (ctx) => {
    const list = ids(ctx.body.ids);
    const who = await db.all(`SELECT full_name, email FROM alumni WHERE approved=0 AND id IN (${marks(list)})`, list);
    const r = await db.run(`UPDATE alumni SET approved=1, approved_at=? WHERE approved=0 AND id IN (${marks(list)})`, [nowIso(), ...list]);
    for (const w of who) sendMail(w.email, 'Your PKR Alumni account is approved', `Hi ${w.full_name},\n\nYour alumni account has been approved. You can now log in to the PKR Alumni app.`);
    return { ok: true, approved: r.changes };
  });
  route('POST', '/api/admin/reject', { auth: 'admin' }, async (ctx) => {
    const list = ids(ctx.body.ids);
    const r = await db.run(`DELETE FROM alumni WHERE approved=0 AND id IN (${marks(list)})`, list);
    return { ok: true, removed: r.changes };
  });

  route('GET', '/api/admin/alumni', { auth: 'admin' }, async (ctx) => {
    const q = (ctx.query.get('q') || '').trim().slice(0, 60);
    const like = '%' + q.replace(/[%_\\]/g, (c) => '\\' + c) + '%';
    const rows = await db.all(
      `SELECT ${PROFILE_COLS} FROM alumni WHERE approved=1 ${q ? `AND (full_name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\')` : ''} ORDER BY full_name COLLATE NOCASE LIMIT 300`,
      q ? [like, like, like] : []);
    return { alumni: rows.map(fullProfile) };
  });
  route('DELETE', '/api/admin/alumni/:id', { auth: 'admin' }, async (ctx) => {
    const id = Number(ctx.params.id);
    await db.run('DELETE FROM messages WHERE sender_id=? OR receiver_id=?', [id, id]);
    await db.run('DELETE FROM group_chat WHERE alumni_id=?', [id]);
    const r = await db.run('DELETE FROM alumni WHERE id=?', [id]);
    return { ok: true, removed: r.changes };
  });
  route('POST', '/api/admin/alumni/:id/reset-password', { auth: 'admin' }, async (ctx) => {
    const temp = crypto.randomBytes(7).toString('base64url');
    const r = await db.run('UPDATE alumni SET password_hash=? WHERE id=?', [await hashPassword(temp), Number(ctx.params.id)]);
    if (!r.changes) throw new HttpError(404, 'Alumni not found.');
    return { ok: true, temporary_password: temp };
  });

  route('GET', '/api/admin/export.csv', { auth: 'admin' }, async (ctx) => {
    const rows = await db.all(`SELECT full_name, email, phone, degree, grad_year, status, job_role, company_name, location, linkedin, created_at FROM alumni WHERE approved=1 ORDER BY full_name COLLATE NOCASE`);
    const cols = ['full_name', 'email', 'phone', 'degree', 'grad_year', 'status', 'job_role', 'company_name', 'location', 'linkedin', 'created_at'];
    const cell = (v) => {
      let s = v === null || v === undefined ? '' : String(v);
      if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralise spreadsheet formulas
      return '"' + s.replace(/"/g, '""') + '"';
    };
    const csv = '﻿' + [cols.join(','), ...rows.map((r) => cols.map((c) => cell(r[c])).join(','))].join('\r\n');
    ctx.raw = { type: 'text/csv; charset=utf-8', body: Buffer.from(csv), cache: 'no-store', disposition: 'attachment; filename="pkr-alumni.csv"' };
  });

  route('GET', '/api/admin/reviews', { auth: 'admin' }, async () => ({
    reviews: await db.all('SELECT id, name, email, rating, review, approved, created_at FROM ratings ORDER BY approved, id DESC LIMIT 200'),
  }));
  route('POST', '/api/admin/reviews/:id/approve', { auth: 'admin' }, async (ctx) => {
    await db.run('UPDATE ratings SET approved=1 WHERE id=?', [Number(ctx.params.id)]);
    return { ok: true };
  });
  route('DELETE', '/api/admin/reviews/:id', { auth: 'admin' }, async (ctx) => {
    await db.run('DELETE FROM ratings WHERE id=?', [Number(ctx.params.id)]);
    return { ok: true };
  });

  route('GET', '/api/admin/contacts', { auth: 'admin' }, async () => ({
    messages: await db.all('SELECT id, name, email, message, done, created_at FROM contact_messages ORDER BY done, id DESC LIMIT 200'),
  }));
  route('POST', '/api/admin/contacts/:id/done', { auth: 'admin' }, async (ctx) => {
    await db.run('UPDATE contact_messages SET done=1 WHERE id=?', [Number(ctx.params.id)]);
    return { ok: true };
  });
  route('DELETE', '/api/admin/contacts/:id', { auth: 'admin' }, async (ctx) => {
    await db.run('DELETE FROM contact_messages WHERE id=?', [Number(ctx.params.id)]);
    return { ok: true };
  });

  route('GET', '/api/admin/group', { auth: 'admin' }, async () => ({
    messages: await db.all(`SELECT g.id, g.body, g.created_at, a.full_name FROM group_chat g LEFT JOIN alumni a ON a.id=g.alumni_id ORDER BY g.id DESC LIMIT 100`),
  }));
  route('DELETE', '/api/admin/group/:id', { auth: 'admin' }, async (ctx) => {
    await db.run('DELETE FROM group_chat WHERE id=?', [Number(ctx.params.id)]);
    return { ok: true };
  });

  route('PUT', '/api/admin/password', { auth: 'admin' }, async (ctx) => {
    const row = await db.get('SELECT pw_hash FROM admin WHERE id=?', [ctx.admin.a]);
    if (!(await verifyPassword(String(ctx.body.current || ''), row.pw_hash))) throw new HttpError(403, 'Current password is incorrect.');
    const next = password(ctx.body.next);
    if (next.length < 10) throw bad('Admin password must be at least 10 characters.');
    await db.run('UPDATE admin SET pw_hash=? WHERE id=?', [await hashPassword(next), ctx.admin.a]);
    return { ok: true };
  });

  /* ---------------- optional email (Brevo HTTP API) ---------------- */
  function sendMail(to, subject, text) {
    const key = process.env.BREVO_API_KEY, from = process.env.MAIL_FROM;
    if (!key || !from || !to) return;
    fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: { 'api-key': key, 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ sender: { name: 'PKR Alumni', email: from }, to: [{ email: to }], subject, textContent: text }),
    }).catch((e) => console.error('mail failed:', e.message));
  }

  /* ---------------- static files ---------------- */
  const MIME = {
    '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml',
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
    '.mp4': 'video/mp4', '.txt': 'text/plain; charset=utf-8', '.woff2': 'font/woff2',
  };
  const gzCache = new Map();
  function serveStatic(req, res, pathname) {
    let rel = decodeURIComponent(pathname);
    if (rel === '/') rel = '/index.html';
    const file = path.normalize(path.join(PUBLIC, rel));
    if (!file.startsWith(PUBLIC + path.sep)) return notFound(res);
    let st;
    try { st = fs.statSync(file); } catch { st = null; }
    if (!st || !st.isFile()) {
      // SPA fallback for navigations (not for files with extensions)
      if (!path.extname(rel) && req.method === 'GET') return serveStatic(req, res, '/index.html');
      return notFound(res);
    }
    const ext = path.extname(file).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const isShell = /\.(html|js|css|webmanifest)$/.test(ext + '') || file.endsWith('sw.js');
    const headers = {
      'Content-Type': type,
      'Cache-Control': isShell ? 'no-cache' : 'public, max-age=86400',
      ETag: `W/"${st.size}-${Math.floor(st.mtimeMs)}"`,
      'Accept-Ranges': 'bytes',
      ...secHeaders(),
    };
    if (req.headers['if-none-match'] === headers.ETag) { res.writeHead(304, headers); return res.end(); }
    const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (range && (range[1] || range[2])) {
      let start = range[1] ? Number(range[1]) : st.size - Number(range[2]);
      let end = range[1] && range[2] ? Number(range[2]) : st.size - 1;
      end = Math.min(end, st.size - 1);
      if (start > end || start < 0) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end(); }
      res.writeHead(206, { ...headers, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': end - start + 1 });
      return req.method === 'HEAD' ? res.end() : fs.createReadStream(file, { start, end }).pipe(res);
    }
    const compressible = /^(text\/|application\/(json|manifest)|image\/svg)/.test(type) && st.size > 1024;
    if (compressible && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
      const key = file + st.mtimeMs;
      if (!gzCache.has(key)) gzCache.set(key, zlib.gzipSync(fs.readFileSync(file)));
      const gz = gzCache.get(key);
      res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', Vary: 'Accept-Encoding', 'Content-Length': gz.length });
      return req.method === 'HEAD' ? res.end() : res.end(gz);
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    return req.method === 'HEAD' ? res.end() : fs.createReadStream(file).pipe(res);
  }
  const notFound = (res) => { res.writeHead(404, { 'Content-Type': 'text/plain', ...secHeaders() }); res.end('Not found'); };

  function secHeaders() {
    return {
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
      'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; media-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; manifest-src 'self'; worker-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
    };
  }

  /* ---------------- request handler ---------------- */
  function readBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = []; let n = 0;
      req.on('data', (c) => { n += c.length; if (n > 1.2e6) { reject(new HttpError(413, 'Request too large.')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => {
        if (!n) return resolve({});
        try { const o = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(o && typeof o === 'object' && !Array.isArray(o) ? o : {}); }
        catch { reject(bad('Invalid request.')); }
      });
      req.on('error', reject);
    });
  }

  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x');
    const { pathname } = u;
    try {
      if (!pathname.startsWith('/api/') && pathname !== '/healthz') {
        if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end(); }
        return serveStatic(req, res, pathname);
      }
      const r = routes.find((x) => x.method === req.method && x.re.test(pathname));
      if (!r) throw new HttpError(404, 'Not found.');
      const m = r.re.exec(pathname);
      const fwd = (req.headers['x-forwarded-for'] || '').split(',')[0].trim();
      const ctx = {
        req, res, query: u.searchParams, params: Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])])),
        ip: (process.env.TRUST_PROXY === '0' ? '' : fwd) || req.socket.remoteAddress || 'ip',
        https: (req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https' || IS_PROD,
        cookies: [], cookies_in: parseCookies(req.headers.cookie), body: {}, user: null, admin: null, raw: null,
      };
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        // CSRF defence: custom header (forces CORS preflight, which we never grant) + same-origin check
        if (req.headers['x-requested-with'] !== 'pkr') throw new HttpError(403, 'Blocked.');
        const origin = req.headers.origin;
        if (origin && new URL(origin).host !== req.headers.host) throw new HttpError(403, 'Blocked.');
        ctx.body = await readBody(req);
      }
      // auth
      const au = r.auth;
      if (au === 'user' || au === 'any') {
        const t = readToken(ctx.cookies_in.sid);
        if (t && t.u) ctx.user = await db.get('SELECT id, full_name FROM alumni WHERE id=? AND approved=1', [t.u]);
      }
      if (au === 'admin' || au === 'any') {
        const t = readToken(ctx.cookies_in.aid);
        if (t && t.a) ctx.admin = await db.get('SELECT id FROM admin WHERE id=?', [t.a]) && t;
      }
      if (au === 'user' && !ctx.user) throw new HttpError(401, 'Please log in.');
      if (au === 'admin' && !ctx.admin) throw new HttpError(401, 'Admin login required.');
      if (au === 'any' && !ctx.user && !ctx.admin) throw new HttpError(401, 'Please log in.');

      const out = await r.handler(ctx);
      const base = { ...secHeaders(), 'Cache-Control': 'no-store' };
      if (ctx.cookies.length) base['Set-Cookie'] = ctx.cookies;
      if (ctx.raw) {
        const h = { ...base, 'Content-Type': ctx.raw.type, 'Cache-Control': ctx.raw.cache || 'no-store', 'Content-Length': ctx.raw.body.length };
        if (ctx.raw.disposition) h['Content-Disposition'] = ctx.raw.disposition;
        res.writeHead(200, h); return res.end(ctx.raw.body);
      }
      const json = JSON.stringify(out === undefined ? { ok: true } : out);
      res.writeHead(200, { ...base, 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(json) });
      res.end(json);
    } catch (e) {
      const status = e instanceof HttpError ? e.status : 500;
      if (status === 500) console.error(e);
      if (res.headersSent) return res.end();
      const json = JSON.stringify({ error: status === 500 ? 'Something went wrong. Please try again.' : e.message });
      res.writeHead(status, { ...secHeaders(), 'Cache-Control': 'no-store', 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(json) });
      res.end(json);
    }
  });

  server.listen(PORT, '0.0.0.0', () => console.log(`PKR Alumni running on http://localhost:${PORT}  (database: ${db.kind})`));
}

main().catch((e) => { console.error('Fatal:', e); process.exit(1); });
